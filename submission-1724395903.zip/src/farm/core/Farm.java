package farm.core;

import farm.customer.AddressBook;
import farm.customer.Customer;
import farm.inventory.BasicInventory;
import farm.inventory.FancyInventory;
import farm.inventory.Inventory;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import farm.sales.TransactionHistory;
import farm.sales.TransactionManager;
import farm.sales.transaction.Transaction;

import java.util.List;

/**
 * The top-level model class responsible for managing the internal state of the farm.
 */
public class Farm {
    private Inventory inventory;
    private AddressBook addressBook;
    private TransactionManager transactionManager;
    private TransactionHistory transactionHistory;

    /**
     * Constructor for the Farm that creates a new farm instance with an inventory and address book.
     * @param inventory The inventory through which access to the farm's stock is provisioned.
     * @param addressBook The address book storing the farm's customer records.
     */
    public Farm(Inventory inventory, AddressBook addressBook) {
        this.inventory = inventory;
        this.addressBook = addressBook;

        // Initialise a transaction manager and transaction history.
        this.transactionManager = new TransactionManager();
        this.transactionHistory = new TransactionHistory();

    }

    /**
     * Retrieves all customers in the farm's address book.
     * @return A list of all customers in the address book.
     * @ensures The returned list is a shallow copy and cannot modify the original address book.
     */
    public List<Customer> getAllCustomers() {
        return addressBook.getAllRecords();
    }

    /** Retrieves all products currently stored in the farm's inventory.
     * @return A list of all products in the inventory.
     * @ensures The returned list is a shallow copy and cannot modify the original inventory.
     */
    public List<Product> getAllStock() {
        return inventory.getAllProducts();
    }

    /**
     * Retrieves the farm's transaction manager.
     * @return The farm's transaction manager.
     */
    public TransactionManager getTransactionManager() {
        return this.transactionManager;
    }

    /**
     * Retrieves the farm's transaction history.
     * @return The farm's transaction history.
     */
    public TransactionHistory getTransactionHistory() {
        return this.transactionHistory;
    }

    public void saveCustomer(Customer customer)
                  throws DuplicateCustomerException {
        this.addressBook.addCustomer(customer);
    }

    public void stockProduct(Barcode barcode,
                             Quality quality) {
        this.inventory.addProduct(barcode, quality);
    }

    public void stockProduct(Barcode barcode,
                             Quality quality,
                             int quantity) throws InvalidStockRequestException {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be at least 1.");
        } else if (quantity > 1 && !(inventory instanceof FancyInventory)) {
            throw new InvalidStockRequestException();
        }

        this.inventory.addProduct(barcode, quality, quantity);
    }

    public void startTransaction(Transaction transaction)
                      throws FailedTransactionException {
        this.transactionManager.setOngoingTransaction(transaction);
    }

    public int addToCart(Barcode barcode)
              throws FailedTransactionException {

        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("Cannot add to cart when no customer has started shopping.");
        }

        List<Product> products = this.inventory.getAllProducts();
        for (Product product : products) {
            if (product.getBarcode().equals(barcode)) {
                this.transactionManager.registerPendingPurchase(product);
                return 1;
            }
        }
        return 0;
    }

    public int addToCart(Barcode barcode, int quantity)
              throws FailedTransactionException {

        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("Cannot add to cart when no customer has started shopping.");
        } else if (quantity < 1) {
            throw new IllegalArgumentException("Quantity must be at least one.");
        } else if (quantity > 1 && (inventory instanceof BasicInventory)) {
            throw new FailedTransactionException("Current inventory is not fancy enough. Please purchase products one at a time.");
        }

        int numAdded = 0;
        List<Product> products = this.inventory.getAllProducts();
        for (Product product : products) {
            if (product.getBarcode().equals(barcode) && numAdded < quantity) {
                this.transactionManager.registerPendingPurchase(product);
                numAdded++;
            }
        }
        return numAdded;
    }


    public boolean checkout()
                 throws FailedTransactionException {
        Transaction closedTransaction = this.transactionManager.closeCurrentTransaction();
        if (!closedTransaction.getPurchases().isEmpty()) {
            this.transactionHistory.recordTransaction(closedTransaction);
            return true;
        }
        return false;
    }

    public String getLastReceipt() {
        Transaction transaction = transactionHistory.getLastTransaction();
        return transaction.getReceipt();
    }

    public Customer getCustomer(String name, int phoneNumber)
            throws CustomerNotFoundException {
        return addressBook.getCustomer(name, phoneNumber);
    }
}
