package farm.core;

import farm.customer.AddressBook;
import farm.customer.Customer;
import farm.inventory.FancyInventory;
import farm.inventory.Inventory;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import farm.sales.TransactionHistory;
import farm.sales.TransactionManager;
import farm.sales.transaction.Transaction;

import java.util.List;

public class Farm {
    public Inventory inventory;
    public AddressBook addressBook;
    public TransactionManager transactionManager;
    public TransactionHistory transactionHistory;

    public Farm(Inventory inventory, AddressBook addressBook) {
        this.inventory = inventory;
        this.addressBook = addressBook;
        this.transactionManager = new TransactionManager();
        this.transactionHistory = new TransactionHistory();

    }

    public List<Customer> getAllCustomers() {
        return addressBook.getAllRecords();
    }

    public List<Product> getAllStock() {
        return inventory.getAllProducts();
    }

    public TransactionManager getTransactionManager() {
        return transactionManager;
    }

    public TransactionHistory getTransactionHistory() {
        return transactionHistory;
    }

    public void saveCustomer(Customer customer)
                  throws DuplicateCustomerException {
        this.addressBook.addCustomer(customer);
    }

    public void stockProduct(Barcode barcode,
                             Quality quality) {
        this.inventory.addProduct(barcode, quality);
    }

    public void stockProduct(Barcode barcode,
                             Quality quality,
                             int quantity) throws InvalidStockRequestException {
        if (quantity <= 0) {
            throw new InvalidStockRequestException("Quantity must be at least one.");
        } else if (quantity > 1 && !(inventory instanceof FancyInventory)) {
            throw new InvalidStockRequestException();
        }

        this.inventory.addProduct(barcode, quality, quantity);
    }

    public void startTransaction(Transaction transaction)
                      throws FailedTransactionException {
        this.transactionManager.setOngoingTransaction(transaction);
    }

    public int addToCart(Barcode barcode)
              throws FailedTransactionException {

        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("Cannot add to cart when no customer has started shopping.");
        }

        List<Product> products = this.inventory.getAllProducts();
        for (Product product : products) {
            if (product.getBarcode().equals(barcode)) {
                this.transactionManager.registerPendingPurchase(product);
                return 1;
            }
        }
        return 0;
    }

    public int addToCart(Barcode barcode, int quantity)
              throws FailedTransactionException {

        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("Cannot add to cart when no customer has started shopping.");
        } else if (quantity < 1) {
            throw new IllegalArgumentException("Quantity must be at least 1.");
        } else if (quantity > 1 && !(inventory instanceof FancyInventory)) {
            throw new FailedTransactionException("Current inventory is not fancy enough. Please purchase products one at a time.");
        }

        int numAdded = 0;
        List<Product> products = this.inventory.getAllProducts();
        for (Product product : products) {
            if (product.getBarcode().equals(barcode) && numAdded < quantity) {
                this.transactionManager.registerPendingPurchase(product);
                numAdded++;
            }
        }
        return numAdded;
    }


    public boolean checkout()
                 throws FailedTransactionException {
        Transaction closedTransaction = this.transactionManager.closeCurrentTransaction();
        if (!closedTransaction.getPurchases().isEmpty()) {
            this.transactionHistory.recordTransaction(closedTransaction);
            return true;
        }
        return false;
    }

    public String getLastReceipt() {
        Transaction transaction = transactionHistory.getLastTransaction();
        return transaction.getReceipt();
    }

    public Customer getCustomer(String name, int phoneNumber)
            throws CustomerNotFoundException {
        return addressBook.getCustomer(name, phoneNumber);
    }
}
