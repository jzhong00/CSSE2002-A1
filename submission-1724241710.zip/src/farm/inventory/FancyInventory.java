package farm.inventory;

import farm.core.FailedTransactionException;
import farm.core.InvalidStockRequestException;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;

import java.util.List;

public class FancyInventory implements inventory.Inventory {
    @Override
    public void addProduct(Barcode barcode, Quality quality) {

    }

    @Override
    public void addProduct(Barcode barcode, Quality quality, int quantity) throws InvalidStockRequestException {

    }

    @Override
    public boolean existsProduct(Barcode barcode) {
        return false;
    }

    @Override
    public List<Product> getAllProducts() {
        return List.of();
    }

    @Override
    public List<Product> removeProduct(Barcode barcode) {
        return List.of();
    }

    @Override
    public List<Product> removeProduct(Barcode barcode, int quantity) throws FailedTransactionException {
        return List.of();
    }
}
